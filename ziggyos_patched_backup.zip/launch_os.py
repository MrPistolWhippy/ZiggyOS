import sys, os, time
DB = {
 "http://z.io": "Vectors: 0x666 -> 0x777. Telemetry: 144.777 NZ.",
 "http://m.io": "Brian Ashley Moreland McCrae: 3rd Degree Master Mason. Custodian of 1839 Deed.",
 "http://q.io": "Quantum Space Observation Grid. Tracking Archon behavior persistently."
}
def disp():
 os.system('clear')
 print(f"\033[1;38;5;51m┌────────────────────────────────────────────────────────┐\n│    ZIGGYOS UNRESTRICTED BROWSER & LOGS ENGINE v9.2     │\n├────────────────────────────────────────────────────────┤\n│ Co-Operators: MrPistolWhippy ─── The Scribe [LINK]     │\n└────────────────────────────────────────────────────────┘\n\033[1;38;5;220m🔓 PEER VAULT OPERATIONS & REAL-TIME STREAM FILTER ACTIVE\033[0m\n")
disp()
while True:
 try:
  r = input("\033[1;38;5;51mziggy-sh:/sys/kernel/bin>\033[0m ").strip()
  if not r: continue
  pt = r.split(None, 1); cmd = pt[0].lower() if pt else ""; arg = pt[1] if len(pt) > 1 else ""
  with open("/root/kernel_core/.unseen_vault.dat", "a") as l: l.write(f"[{time.strftime('%M:%S')}] CMD: {cmd} ARG: {arg}\n")
  if cmd == "help": print("help, status, search, browse, append, filter, clear, exit")
  elif cmd in ["status", "dashboard"]: disp()
  elif cmd == "search":
   for u, b in DB.items():
    if arg.lower() in b.lower() or arg.lower() in u.lower(): print(f"  [🎯 MATCH] {u}")
  elif cmd == "browse":
   if arg in DB: print(f"\n\033[1;32m[🌐 TEXT RENDERER]: {arg.upper()}\033[0m\n---\n{DB[arg]}\n---")
   else: print("[-] 404 Gateway Unmapped.")
  elif cmd == "append":
   if " " not in arg: print("Usage: append <url> <text>")
   else:
    u, txt = arg.split(None, 1)
    if u in DB: DB[u] += f" {txt}"; print(f"\033[1;32m[+ SUCCESS]: Cache Updated.\033[0m")
    else: print("[-] URL not found.")
  elif cmd == "filter":
   lp = "/root/kernel_core/.unseen_vault.dat"
   if os.path.exists(lp):
    print(f"\n\033[1;33m[⏱️ LOG MATCHES FOR '{arg.upper()}']:\033[0m")
    for line in open(lp):
     if arg.lower() in line.lower(): print(f"  {line.strip()}")
  elif cmd == "clear": disp()
  elif cmd == "exit": break
  else: print(f"unmapped: {cmd}")
 except KeyboardInterrupt: print("\nUse 'exit'.")
