#include <stdint.h>
#define REG(x) (*(volatile uint32_t*)(x))
static uint16_t cx = 0; static int16_t ly = 160;
void w_cmd(uint8_t c) { while((REG(0x400C4004) & 2) == 0); REG(0x400C4008) = c; }
void w_dat(uint8_t d) { while((REG(0x400C4004) & 2) == 0); REG(0x400C4008) = d; }
void set_win(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1) {
    w_cmd(0x2A); w_dat(x0>>8); w_dat(x0); w_dat(x1>>8); w_dat(x1);
    w_cmd(0x2B); w_dat(y0>>8); w_dat(y0); w_dat(y1>>8); w_dat(y1); w_cmd(0x2C);
}
void draw_line(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint16_t c) {
    int16_t dx = (x1>x0)?(x1-x0):(x0-x1), dy = (y1>y0)?(y1-y0):(y0-y1);
    int16_t sx = (x0<x1)?1:-1, sy = (y0<y1)?1:-1, err = dx - dy;
    while (1) {
        set_win(x0, y0, x0, y0); w_dat(c >> 8); w_dat(c);
        if (x0 == x1 && y0 == y1) break;
        int16_t e2 = 2 * err;
        if (e2 > -dy) { err -= dy; x0 += sx; }
        if (e2 < dx) { err += dx; y0 += sy; }
    }
}
void Reset_Handler(void) {
    REG(0xE000ED94) = 0; REG(0x40087004) |= 0x30;
    set_win(0, 0, 240, 320); for(uint32_t i=0; i<76800; i++) { w_dat(0); w_dat(0); }
    while (1) {
        // Toggle raw audio drive pin high
        REG(0x400F4200) = (1 << 4);
        for(volatile int d=0; d<5000; d++);
        
        // Render step edge trace upwards on display timeline
        int16_t ny = 120;
        draw_line(cx, ly, cx + 2, ny, 0x07E0);
        
        // Toggle raw audio drive pin low
        REG(0x400F4280) = (1 << 4);
        for(volatile int d=0; d<5000; d++);
        
        // Render step edge trace downwards on display timeline
        ly = ny; ny = 200;
        draw_line(cx + 2, ly, cx + 4, ny, 0x07E0);
        ly = ny; cx += 4;
        
        // Clear canvas line path ahead and wrap screen window boundaries
        if (cx >= 236) {
            cx = 0; set_win(0, 50, 240, 250);
            for(uint32_t i=0; i<48000; i++) { w_dat(0); w_dat(0); }
        }
    }
}
