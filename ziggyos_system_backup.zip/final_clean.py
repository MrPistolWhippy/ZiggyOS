with open('src/main.c', 'r') as f:
    code = f.read()

# 1. Clean up any accidental stray backslashes or corrupted syntax from previous attempts
code = code.replace('&', '&')
code = code.replace('(*cmd_buffer)', 'cmd_buffer')

# 2. Force rewrite lines 172-184 with perfect clean bracket indexing syntax
lines = code.split('\n')
for i, line in enumerate(lines):
    # Detect the calculator line block to fix it cleanly
    if "else if" in line and "'c'" in line and "'a'" in line:
        lines[i] = "    } else if (cmd_buffer[0] == 'c' && cmd_buffer[1] == 'a' && cmd_buffer[2] == 'l') {"
    if "app_run_calculator" in line and "(" in line:
        lines[i] = "        extern void app_run_calculator(const char* e); app_run_calculator(cmd_buffer);"
    if "else if" in line and "'c'" in line and "'r'" in line:
        lines[i] = "    } else if (cmd_buffer[0] == 'c' && cmd_buffer[1] == 'r') {"
    if "else if" in line and "'u'" in line and "'s'" in line:
        lines[i] = "    } else if (cmd_buffer[0] == 'u' && cmd_buffer[1] == 's') {"
    if "else if" in line and "'t'" in line and "'h'" in line:
        lines[i] = "    } else if (cmd_buffer[0] == 't' && cmd_buffer[1] == 'h') {"
    if "app_set_system_theme" in line and "(" in line:
        lines[i] = "        extern void app_set_system_theme(char s); app_set_system_theme(cmd_buffer[2]);"
    if "else if" in line and "'t'" in line and "'o'" in line:
        lines[i] = "    } else if (cmd_buffer[0] == 't' && cmd_buffer[1] == 'o') {"
    if "else if" in line and "'n'" in line and "'a'" in line:
        lines[i] = "    } else if (cmd_buffer[0] == 'n' && cmd_buffer[1] == 'a') {"

with open('src/main.c', 'w') as f:
    f.write('\n'.join(lines))

print("✨ Stray slashes cleared and perfect bracket indexes applied!")
