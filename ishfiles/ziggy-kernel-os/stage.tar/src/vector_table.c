#include <stdint.h>

extern void Reset_Handler(void);
extern void _estack(void); // Defined dynamically via linker script symbols

// Force allocation into the specific vector section layout
__attribute__((section(".vectors"), used))
void (* const vector_table[])(void) = {
    (void (*)(void))((uint32_t)&_estack), // 0x00: Initial Top of Stack Pointer
    Reset_Handler                         // 0x04: Reset Handler Execution Address
};
