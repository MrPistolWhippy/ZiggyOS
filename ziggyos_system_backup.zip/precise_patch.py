with open('src/main.c', 'r') as f:
    lines = f.readlines()

# Completely rewrite the broken command block from line 172 to 184 cleanly
lines[171] = "    } else if (cmd_buffer[0] == 'c' && cmd_buffer[1] == 'a' && cmd_buffer[2] == 'l') {\n"
lines[172] = "        extern void app_run_calculator(const char* e);\n"
lines[173] = "        app_run_calculator(cmd_buffer);\n"
lines[174] = "    } else if (cmd_buffer[0] == 'c' && cmd_buffer[1] == 'r') {\n"
lines[175] = "        extern void app_crypt_file(); app_crypt_file();\n"
lines[176] = "    } else if (cmd_buffer[0] == 'u' && cmd_buffer[1] == 's') {\n"
lines[177] = "        extern void app_user_add(const char* n, const char* p); app_user_add(\"guest\", \"1234\");\n"
lines[178] = "    } else if (cmd_buffer[0] == 't' && cmd_buffer[1] == 'h') {\n"
lines[179] = "        extern void app_set_system_theme(char s); app_set_system_theme(cmd_buffer[2]);\n"
lines[180] = "    } else if (cmd_buffer[0] == 't' && cmd_buffer[1] == 'o') {\n"
lines[181] = "        extern void app_run_top_monitor(); app_run_top_monitor(); print(\"-> \");\n"
lines[182] = "    } else if (cmd_buffer[0] == 'n' && cmd_buffer[1] == 'a') {\n"
lines[183] = "        extern void app_run_nano_editor(); app_run_nano_editor();\n"

with open('src/main.c', 'w') as f:
    f.writelines(lines)
print("✨ Precise array patch applied!")
